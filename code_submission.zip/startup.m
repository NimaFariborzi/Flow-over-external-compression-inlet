% Set default figure size and windowstate
set(groot, 'DefaultFigureWindowState','maximized')
set(groot, 'DefaultFigureUnits','normalized')
set(groot, 'DefaultFigurePosition',[0.2 0.1 0.6 0.75])

% Set default axis font size to 30
set(groot, 'DefaultAxesFontSize', 30);

% Set default line width to 3
set(groot, 'DefaultLineLineWidth', 3)

% Turn grid on by default in plots
set(groot, 'DefaultAxesXGrid', 'on')
set(groot, 'DefaultAxesYGrid', 'on')
set(groot, 'DefaultAxesZGrid', 'on')

% Set text interpreters to latex
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex');
set(groot, 'DefaultColorbarTickLabelInterpreter', 'latex');
set(groot, 'DefaultTextInterpreter', 'latex');
set(groot, 'DefaultLegendInterpreter', 'latex');
% For the colorbar, there is no way to set the default label interpreter
% Workaround as follows:
% cb = colorbar(...);
% cb.Label.Interpreter = 'latex';
% Also needs to be set manually for shared title/labels in TiledLayout charts...

% Set default colormap to turbo
set(groot, 'DefaultFigureColormap', turbo);

% Using shading interp by default on surface plots
set(groot, 'DefaultSurfaceFaceColor', 'interp')
set(groot, 'DefaultSurfaceEdgeColor', 'none')

% Set colorbar tick direction to out
set(groot, 'DefaultColorbarTickDirection', 'out');