Notes about this submission:

The workflow to run this code is as follows:

- Generate a mesh with "generate_mesh.m" Results are saved as "mesh.mat"
	- The values in that file are currently set to generate the coarse mesh used
      in our analysis
	- The fine mesh can be obtained by simply halving d_xi and d_eta
- Process the mesh with "process_mesh.m" to calculate and save grid metrics in
  "mesh_metrics.mat"
- Run the main simulation code "inlet_dns.m"
	- The time controls are sufficient for the coarse mesh. To run the finer
      mesh the timestep needs to be reduced. For our run on the fine mesh,
      dt = 3e-12 was used.
    - Results are saved in "results.mat" upon completion
- Results are post-processed with "plots.m" to generate larger plots and
  "calc_pressure_drop.m" to calculate the stagnation pressure drop across the
  inlet. They take "results.mat" and "mesh.mat" as inputs.

You can skip directly to running inlet_dns.m if you like. A coarse mesh and the
required mesh metrics are already provided with this submission. Results are
provided as well if you don't want to wait for the simulation to finish (though
it shouldn't take too long).

In order for plots to generate correctly, the file 'startup.m' should be run to
set the graphics defaults to the same values used by us. However those defaults
are set up to work on my (Michael's) screen resolution of 1440p, so plots may
look different on your screen.